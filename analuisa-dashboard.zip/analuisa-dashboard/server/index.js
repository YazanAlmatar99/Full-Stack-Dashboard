const express = require ('express');
const mongoose = require("mongoose");
const cookieSession = require("cookie-session");
const cookieParser = require('cookie-parser');
const passport = require("passport");
const bodyParser = require('body-parser');
const keys = require('./config/keys')
const path = require('path');
require("./models/User");
require("./models/Horoscope");
require("./models/Product");
require("./models/Inventory");
require("./OAuth/passport");
const app = express();
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, auth');
  res.header('Access-Control-Allow-Credentials', 'true');
  next();
});
console.log('node_env')
console.log(process.env.NODE_ENV)
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(
    cookieSession({
      maxAge: 30 * 24 * 60 * 60 * 1000,
      keys: [keys.cookieKey]
    })
  );
app.use(cookieParser());

app.use(passport.initialize());
app.use(passport.session());

if (process.env.NODE_ENV === 'production') {
  console.log('PROD');
  // Serve any static files
  app.use(express.static(path.join(__dirname, 'client/build')));

  // Handle React routing, return all requests to React app
  app.get('*', function(req, res) {
    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'),(error)=>{
      if (error){
        res.send(error) 
      }
    });
  });
}
// app.use(express.static(path.join(__dirname, 'al-dashbaord/build')));
// app.get('*', (req, res) => {fdsaf
//   res.sendFile(path.join(__dirname+'/al-dashboard/build/index.html'));
// });
mongoose.set('useFindAndModify', false);
mongoose.connect(keys.mongoURI,{useNewUrlParser: true});
require("./routes/fetchRoutes")(app);
require("./routes/authRoutes")(app);
require("./routes/inventoryRoutes")(app);
 const PORT = process.env.PORT || 5000
 console.log(PORT)

 app.listen(PORT);

