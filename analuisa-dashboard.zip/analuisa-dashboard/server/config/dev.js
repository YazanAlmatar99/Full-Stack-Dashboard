module.exports = {
    googleClientID:"1030601223094-5pphbi1pt79iq47cbglr0rar9klcnmfa.apps.googleusercontent.com",
    googleClientSecret: "qjueawaeVr2XS3z3WaX-zg6P",
    mongoURI: "mongodb+srv://dashboard-admin:udzddozkG85lIS6O@cluster0-dashboard-al-kaiic.mongodb.net/test?retryWrites=true&w=majority",
    cookieKey: "jfdsaighekaljsfjewhafuewailf",
    googleTriggerKey:"15C65644FBFA3EBE7BC7FE3A14C7A",
    analuisaApiKey:'d13b15cac514905abf5b17ff78fab4fb:d3291873d4e83545fdf6b3e6bcd6112f'
};