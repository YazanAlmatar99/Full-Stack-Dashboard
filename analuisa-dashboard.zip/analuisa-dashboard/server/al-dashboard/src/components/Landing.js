import React from "react";

const Landing = () => {
  return (
    <div style = {{textAlign :'center'}}>
      <h1>Ana Luisa</h1>
    </div>
  );
};
export default Landing;
